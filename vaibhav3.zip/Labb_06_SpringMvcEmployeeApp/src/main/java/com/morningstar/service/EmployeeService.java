package com.morningstar.service;

import java.util.List;

import com.morningstar.dao.EmployeeDao;
import com.morningstar.model.Employee;

public interface EmployeeService {

	public boolean addEmployee(Employee employee);

	public Employee findByEmployeeId(int employeeId);

	public List<Employee> findByAllEmployee();

	public void setDao(EmployeeDao employeeDao);

	public boolean deleteEmployee(int employeeId);

	public boolean updateEmployee(Employee employee);

	public Employee findByName(String name);

	public Employee findMinSalary();
	public Employee findMaxSalary();

	public List<Employee> findBelow10KEmployee();

	public List<Employee> findAbove10KEmployee();

}
