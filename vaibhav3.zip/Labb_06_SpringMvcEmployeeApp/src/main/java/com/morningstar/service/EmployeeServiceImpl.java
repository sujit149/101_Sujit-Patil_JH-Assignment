package com.morningstar.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.morningstar.dao.EmployeeDao;
import com.morningstar.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDao dao;

	public EmployeeDao getDao() {
		return dao;
	}

	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean addEmployee(Employee employee) {
		try {
			int result = dao.createEmployee(employee);
			if (result >= 1) {
				return true;
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Employee findByEmployeeId(int employeeId) {

		Employee employee = null;

		try {
			employee = dao.readEmployee(employeeId);
			System.out.println("Student find by id completed");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return employee;
	}

	public List<Employee> findByAllEmployee() {
		List<Employee> employee = null;
		try {
			employee = dao.readAllEmployees();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employee;
	}

	public boolean updateEmployee(Employee employee) {
		int result;
		try {
			result = dao.updateEmployee(employee);
		} catch (SQLException e) {
			result = 0;
			e.printStackTrace();
		}
		if(result == 1) {
			return true;
		}
		return false;
	}
	
	public boolean deleteEmployee(int employeeId) {
		int result;
		try {
			result = dao.deleteEmployee(employeeId);
		} catch (SQLException e) {
			result = 0;
			e.printStackTrace();
		}
		if(result == 1) {
			return true;
		}
		return false;
	}

	@Override
	public Employee findByName(String name) {
		return dao.findByName(name);
	}

	@Override
	public Employee findMaxSalary() {
		return dao.findMaxSalary();
	}
	@Override
	public Employee findMinSalary() {
		return dao.findMinSalary();
	}


	@Override
	public List<Employee> findBelow10KEmployee() {
		return dao.findBelow10KEmployee();
	}

	@Override
	public List<Employee> findAbove10KEmployee() {
		return dao.findAbove10KEmployee();
	}

}
