package com.morningstar.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.morningstar.model.Employee;

@Repository
public class EmployeeDaoSpringJdbcImpl implements EmployeeDao {

	@Autowired
	private JdbcTemplate template;
	
	
	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public int createEmployee(Employee employee) throws SQLException {
		String query = "Insert into employee(employeeid, employeename,salary, departmentid ) values(?,?,?,?)";
		int result = template.update(query, employee.getEmployeeId(), employee.getEmployeeName(), employee.getSalary(),employee.getDepartmentId());
		return result;
	}


	@Override
	public Employee readEmployee(int employeeId) throws SQLException {
		String query = "Select * from Employee where Employeeid ="+employeeId;
		Employee result = template.queryForObject(query,new EmployeeRowMapper());
		return result;
	}

	@Override
	public List<Employee> readAllEmployees() throws SQLException {
		String query = "select * from employee order by employeeid";
		List<Employee> list = template.query(query, (ResultSet rs, int rowNum) -> {
			Employee employee = new Employee();
			employee.setEmployeeId(rs.getInt("employeeId"));
			employee.setEmployeeName(rs.getString("employeename"));
			employee.setSalary(rs.getDouble("salary"));
			employee.setDepartmentId(rs.getInt("departmentId"));
			return employee;
		});
		return list;
	}

	@Override
	public int updateEmployee(Employee employee) throws SQLException {
		String query = "update employee set employeeName = ?, salary = ?, departmentId = ? where employeeId = ?";
		int result = template.update(query, employee.getEmployeeName(), employee.getSalary(), employee.getDepartmentId(), employee.getEmployeeId());
		return result;
	}

	@Override
	public int deleteEmployee(int emloyeeId) throws SQLException {
		String query = "delete from employee where employeeId = ?";
		int result = template.update(query, emloyeeId);
		return result;
	}

	@Override
	public Employee findByName(String name) {
		String query = "Select * from Employee where EmployeeName ="+"\'"+name+"\'";
		Employee result = template.queryForObject(query,new EmployeeRowMapper());
		return result;
	}

	@Override
	public Employee findMaxSalary() {
		String max = "select * from employee where salary = (select max(salary) from employee)";
		Employee result = template.queryForObject(max, new EmployeeRowMapper());
		return result;
	}
	@Override
	public Employee findMinSalary() {
		String min = "select * from employee where salary = (select min(salary) from employee)";
		Employee result1 = template.queryForObject(min, new EmployeeRowMapper());
		return result1;
	}

	@Override
	public List<Employee> findBelow10KEmployee() {
		String query = "select * from employee where salary > 10000 order by employeeid";
		List<Employee> list = template.query(query, (ResultSet rs, int rowNum) -> {
			Employee employee = new Employee();
			employee.setEmployeeId(rs.getInt("employeeId"));
			employee.setEmployeeName(rs.getString("employeename"));
			employee.setSalary(rs.getDouble("salary"));
			employee.setDepartmentId(rs.getInt("departmentId"));
			return employee;
		});
		return list;
	}

	@Override
	public List<Employee> findAbove10KEmployee() {
		String query = "select * from employee where salary < 10000 order by employeeid";
		List<Employee> list = template.query(query, (ResultSet rs, int rowNum) -> {
			Employee employee = new Employee();
			employee.setEmployeeId(rs.getInt("employeeId"));
			employee.setEmployeeName(rs.getString("employeename"));
			employee.setSalary(rs.getDouble("salary"));
			employee.setDepartmentId(rs.getInt("departmentId"));
			return employee;
		});
		return list;
	}

}
