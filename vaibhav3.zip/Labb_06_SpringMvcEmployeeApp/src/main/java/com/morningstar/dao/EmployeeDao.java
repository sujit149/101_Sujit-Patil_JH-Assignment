package com.morningstar.dao;

import java.sql.SQLException;
import java.util.List;

import com.morningstar.model.Employee;

public interface EmployeeDao {
	
	public int createEmployee(Employee employee) throws SQLException;

	public Employee readEmployee(int employeeId) throws SQLException;
	
	public List<Employee> readAllEmployees() throws SQLException;
	
	public int updateEmployee(Employee employee) throws SQLException;
	
	public int deleteEmployee(int employeeId) throws SQLException;
	
	public Employee findByName(String name);
	
	public Employee findMaxSalary();
	public Employee findMinSalary();

	public List<Employee> findBelow10KEmployee();

	public List<Employee> findAbove10KEmployee();
	
}
