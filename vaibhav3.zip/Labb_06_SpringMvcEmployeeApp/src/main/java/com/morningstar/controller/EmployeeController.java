package com.morningstar.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.morningstar.model.Employee;
import com.morningstar.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@GetMapping(path = "/")
	public String hello() {
		return "index";
	}

	@GetMapping(path = "addEmployeeForm.view")
	public String showStudentForm() {
		return "addEmployee";
	}

	@PostMapping(path = "addEmployee")
	public String addEmployee(Employee employee) {
		boolean result = service.addEmployee(employee);
		if (result)
			return "index";
		else
			return "error";
	}

	@GetMapping(path = "viewEmployee")
	public String getAllStudents(Model model) {
		List<Employee> employees = service.findByAllEmployee();
		model.addAttribute("employeeList", employees);
		return "viewEmployee";
	}

	@GetMapping(path = "readEmployee")
	public String writeEmployeeId() {
		return "getbyid";
	}

	@PostMapping(path = "showDetailEmployee")
	public String showOneEmployeeDetail(@RequestParam("employeeId") String id, Model model) {
		int idNum = Integer.valueOf(id);
		Employee employee = service.findByEmployeeId(idNum);
		model.addAttribute("singleEmployee", employee);
		return "showEmployee";
	}

	@GetMapping(path = "deleteEmployee")
	public String deleteEmployee() {
		return "deleteEmployeeForm";
	}

	@PostMapping(path = "deleteEmployeeFinal")
	public String deleteEmployeeFinal(@RequestParam("employeeId") String id) {
		int num = Integer.parseInt(id);
		boolean status = service.deleteEmployee(num);
		if (status)
			return "index";
		else
			return "error";
	}

	@GetMapping(path = "updateEmployee")
	public String updateEmployee() {
		return "updateEmployeeForm";
	}

	@PostMapping(path = "updateEmployeeFinal")
	public String updateEmployeeFinal(Employee employee) {
		boolean status = service.updateEmployee(employee);
		if (status)
			return "index";
		else
			return "error";
	}

	@GetMapping(path = "findByName")
	public String findByNameEmployee() {
		return "findByNameForm";
	}

	@PostMapping(path = "findByNameFinal")
	public String findByNameFinal(@RequestParam("employeeName") String name, Model model) {
		Employee employee = service.findByName(name);
		model.addAttribute("singleEmployee", employee);
		return "showEmployee";
	}

	@GetMapping(path = "findByAll")
	public String findByAll(Model model) {

		// Min & Max
		model.addAttribute("max", service.findMaxSalary());
		model.addAttribute("min", service.findMinSalary());

		model.addAttribute("Below10K", service.findBelow10KEmployee());
		model.addAttribute("Above10K", service.findAbove10KEmployee());
		return "allView";
	}

}
