package com.morningstar.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.morningstar.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao{

	
	@PersistenceContext
	public EntityManager em;
	
	@Override
	public boolean isNewUser(String email) {
		
		return (long)em.createQuery("select count(*) from Student where studentEmail = :email").
				setParameter("email", email).
				getSingleResult() == 1 ? true : false;
	}

	@Override
	public boolean userRegistration(Student student) {
		
		em.persist(student);
		return true;
	}

	public boolean existUser(String email){
		return (long)em.createQuery("select count(c) from Student c where c.email = :em")
				.setParameter("em", email)
				.getSingleResult() == 1 ? true : false;
	}
	
	}
	
	

