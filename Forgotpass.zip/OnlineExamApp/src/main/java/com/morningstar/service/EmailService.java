package com.morningstar.service;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;
@Service
public class EmailService {
	
	public void otpToUser(String email) {
    	String createdOtp = os.createOtp();
        SimpleMailMessage message = new SimpleMailMessage(); 
        message.setFrom("petcult2022@gmail.com");
        message.setTo(email); 
        message.setSubject("OTP for Validation of registered user."); 
        message.setText(createdOtp);
        emailSender.send(message);
    }

}
