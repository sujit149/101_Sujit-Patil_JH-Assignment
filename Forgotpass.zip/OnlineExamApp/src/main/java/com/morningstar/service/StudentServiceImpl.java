package com.morningstar.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.morningstar.dao.StudentDao;
import com.morningstar.exception.CustomerOtpException;
import com.morningstar.exception.UseralreadyRegistered;
import com.morningstar.model.Student;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	public StudentDao dao;
	@Autowired EmailService es;
	
	@Transactional
	@Override
	public String checkUser(Student student) {
		
		if(dao.isNewUser(student.getStudentEmail())) {
			throw new UseralreadyRegistered("User already registered please go to login page");
		}
		else {
			boolean result = dao.userRegistration(student);
			if(result) {
				return "User Registered";
			}
			else {
				return "Server error";
			}
		}
		
	}

	@Override
	public String isValidUser(Student student) {
		if(dao.existUser(student.getStudentEmail())) {
			es.otpToUser(student.getStudentEmail());
			return student.getStudentEmail();
			
		}
		
		else {
			throw new CustomerOtpException("Please enter valid email Id");
		}
		
		
		
		
	}
	
	
}
