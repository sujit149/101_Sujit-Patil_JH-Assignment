package com.morningstar.service;

import org.springframework.stereotype.Service;

import com.morningstar.model.Student;

public interface StudentService {
	
	public String checkUser(Student student);
	
	public String isValidUser(Student student);

}
