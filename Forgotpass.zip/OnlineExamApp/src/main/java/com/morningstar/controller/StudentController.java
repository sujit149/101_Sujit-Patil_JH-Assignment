package com.morningstar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


import com.morningstar.exception.UseralreadyRegistered;
import com.morningstar.model.Student;
import com.morningstar.service.StudentService;

@Controller
public class StudentController {
	
	
	@Autowired
	StudentService service;
	
	@GetMapping(path = "/")
	public String hello() {
		return "index";
		}
	
	@GetMapping(path = "/Registration.view")
	public String registerPage() {
		return "Registration";
		}
	
	@PostMapping(path = "/registration.do")
	public String registration(Student student, Model model) {
		try {
			String message = service.checkUser(student);
			model.addAttribute("messageObj", message);
			return "Thankyou";
		}
		catch(UseralreadyRegistered e) {
			String message = e.getMessage();
			model.addAttribute("messageObj", message);
			return "Error";
		}
		
	}
	

	@PostMapping("/sendOtp")
	public String userOtp(Student student) {
		
			String checkedEmail = cs.isValidUser(student.getStudentEmail());
			 
		
	
	
	
}
}