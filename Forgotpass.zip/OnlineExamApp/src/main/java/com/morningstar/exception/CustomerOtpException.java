package com.morningstar.exception;

public class CustomerOtpException extends Exception {

	
	public CustomerOtpException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public  CustomerOtpException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
