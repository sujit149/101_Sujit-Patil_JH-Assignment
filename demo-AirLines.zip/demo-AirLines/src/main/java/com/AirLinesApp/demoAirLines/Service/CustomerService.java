package com.AirLinesApp.demoAirLines.Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AirLinesApp.demoAirLines.Entity.Customer;
import com.AirLinesApp.demoAirLines.Exception.CustomerException;
import com.AirLinesApp.demoAirLines.Exception.InvalidLoginException;
import com.AirLinesApp.demoAirLines.Exeception.CustomerOtpException;
import com.AirLinesApp.demoAirLines.Repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository cr;

	@Autowired
	EmailService es;
	
	@Autowired
	OtpService os; 
	
	@Transactional
	public int register(Customer customer) {
		if (cr.existUser(customer.getEmail())) {
			throw new CustomerException("User already exists");
		} else {
			Customer updatedValue = (Customer) cr.Save(customer);
			es.sendMailToNewUser(updatedValue.getEmail());
			return updatedValue.getId();
		}
	}

	@Transactional
	public String isValidUser(Customer customer) {
		if (cr.existUser(customer.getEmail())) {
			es.otpToUser(customer.getEmail());
			return customer.getEmail();
		} else {
			throw new CustomerOtpException(
					"Please enter valid Email Id as the user is not registered click on below button to register");
		}
	}

	
	  public String isValidOtp(String otp) {
		  String message = os.checkOtp(otp);
		  return message;
	  }
	  
	  public void loginCheck(Customer customer) {
		  if(cr.isValidUser(customer.getEmail(), customer.getPassword())){
			  
		  }
		  else {
			  throw new InvalidLoginException("Please enter correct email and password");
		  }
	  }
	 
}
