package com.AirLinesApp.demoAirLines.Service;

import java.util.Random;

import org.springframework.stereotype.Service;

import com.AirLinesApp.demoAirLines.Exception.WrongOtpException;

@Service
public class OtpService {
	
	/*
	 * private static final Integer EXPIRE_MINS = 5; private LoadingCache otpCache;
	 * public OtpService(){ super(); otpCache = CacheBuilder.newBuilder().
	 * expireAfterWrite(EXPIRE_MINS, TimeUnit.MINUTES) .build(new CacheLoader() {
	 * public Integer load(String key) { return 0; } }); }
	 */
	
	static String otp;
	
	
	
	public String createOtp() {
		
		otp = "";
		Random rnd = new Random();
		String selectFrom="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
		while(otp.length()<7) {
            char ch = selectFrom.charAt(rnd.nextInt(selectFrom.length()));
            otp=otp+ch;
		}
		return otp;
	}
	
	public String checkOtp(String userOtp) {
		if(otp.equals(userOtp)) {
			return "Otp verified successfully Please update the password.";
		}
		throw new WrongOtpException("Please enter correct Otp");
	}
}
