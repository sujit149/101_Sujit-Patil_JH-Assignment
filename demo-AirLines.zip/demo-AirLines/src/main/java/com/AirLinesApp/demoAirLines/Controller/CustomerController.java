package com.AirLinesApp.demoAirLines.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.AirLinesApp.demoAirLines.Entity.Customer;
import com.AirLinesApp.demoAirLines.Exception.CustomerException;
import com.AirLinesApp.demoAirLines.Exception.WrongOtpException;
import com.AirLinesApp.demoAirLines.Exeception.CustomerOtpException;
import com.AirLinesApp.demoAirLines.Service.CustomerService;
import com.AirLinesApp.demoAirLines.dto.OtpStatus;
import com.AirLinesApp.demoAirLines.dto.RegsitrationStatus;

@RestController
@CrossOrigin
public class CustomerController {
	
	@Autowired
	CustomerService cs;
	
	@PostMapping("/register")
	public RegsitrationStatus registerUser(@RequestBody Customer customer) {
		try {
			int id = cs.register(customer);
			RegsitrationStatus rs = new RegsitrationStatus();
			rs.setStatus(true);
			rs.setMessage("User Regsitered successfully");
			rs.setRegistrationId(id);
			return rs;
		}
		catch(CustomerException ce) {
			RegsitrationStatus rs = new RegsitrationStatus();
			rs.setStatus(false);
			rs.setMessage(ce.getMessage());
			return rs;
		}
	}
		
		@PostMapping("/sendOtp")
		public String userOtp(@RequestBody Customer customer) {
			try {
				String checkedEmail = cs.isValidUser(customer);
				OtpStatus os = new OtpStatus();
				os.setMessage("Email sent successfully to : "+checkedEmail);
				return os.getMessage();
			}
			catch(CustomerOtpException coe) {
				OtpStatus os = new OtpStatus();
				os.setMessage(coe.getMessage());
				return os.getMessage();
			}
		}
		
		@PostMapping("/getOtp")
		public String checkOtp(@RequestParam String otp) {
			try {
				String message = cs.isValidOtp(otp);
				OtpStatus os = new OtpStatus();
				os.setMessage(message);
				return os.getMessage();
			}
			catch(WrongOtpException woe) {
				OtpStatus os = new OtpStatus();
				os.setMessage(woe.getMessage());
				return os.getMessage();
			}
		}
		
		@GetMapping("/generateSessionID")
		public String Session(HttpSession session) {
			String sessionID = session.getId();
			return sessionID;
		}
		
}
