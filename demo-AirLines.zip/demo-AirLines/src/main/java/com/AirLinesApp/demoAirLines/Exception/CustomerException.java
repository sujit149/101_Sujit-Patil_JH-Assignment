package com.AirLinesApp.demoAirLines.Exception;

public class CustomerException extends RuntimeException {

	public CustomerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
