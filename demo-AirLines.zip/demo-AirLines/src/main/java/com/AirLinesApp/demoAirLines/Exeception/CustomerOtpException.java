package com.AirLinesApp.demoAirLines.Exeception;

public class CustomerOtpException extends RuntimeException {

	public CustomerOtpException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerOtpException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
