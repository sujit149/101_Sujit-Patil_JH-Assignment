package com.AirLinesApp.demoAirLines.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender emailSender;
    
    @Autowired
    private OtpService os;

    public void sendMailToNewUser(String email) {
    	        SimpleMailMessage message = new SimpleMailMessage(); 
    	        message.setFrom("petcult2022@gmail.com");
    	        message.setTo(email); 
    	        message.setSubject("Thank you for registering with us."); 
    	        message.setText("Welcome to PetCult");
    	        emailSender.send(message);
    	    }
    
    public void otpToUser(String email) {
    	String createdOtp = os.createOtp();
        SimpleMailMessage message = new SimpleMailMessage(); 
        message.setFrom("petcult2022@gmail.com");
        message.setTo(email); 
        message.setSubject("OTP for Validation of registered user."); 
        message.setText(createdOtp);
        emailSender.send(message);
    }
}
