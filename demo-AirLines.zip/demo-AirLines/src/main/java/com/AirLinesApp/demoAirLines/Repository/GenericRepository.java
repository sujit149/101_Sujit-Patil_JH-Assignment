package com.AirLinesApp.demoAirLines.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class GenericRepository {
	
	@PersistenceContext
	protected EntityManager em;
	
	public Object Save(Object obj) {
		return em.merge(obj);
	}
}
