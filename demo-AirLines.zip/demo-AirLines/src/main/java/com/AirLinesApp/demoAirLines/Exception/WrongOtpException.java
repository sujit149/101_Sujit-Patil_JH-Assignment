package com.AirLinesApp.demoAirLines.Exception;

public class WrongOtpException extends RuntimeException {

	public WrongOtpException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WrongOtpException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
