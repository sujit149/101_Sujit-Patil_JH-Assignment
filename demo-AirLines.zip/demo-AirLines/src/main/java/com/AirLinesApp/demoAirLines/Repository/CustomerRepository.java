package com.AirLinesApp.demoAirLines.Repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.AirLinesApp.demoAirLines.Entity.Customer;

@Repository
public class CustomerRepository extends GenericRepository {
	
	public boolean isValidUser(String email, String password) {
		return (long) em.createQuery("select count(c) from Customer c where c.email = :em and c.password : pw")
				.setParameter("em", email)
				.setParameter("pw", password)
				.getSingleResult() == 1 ? true : false;
	}
	
	public boolean existUser(String email){
		return (long)em.createQuery("select count(c) from Customer c where c.email = :em")
				.setParameter("em", email)
				.getSingleResult() == 1 ? true : false;
	}
	
	public List<Customer> checkLogin(String email, String password) {
		return em.createQuery("select c from Customer c where c.email = :em and c.password = :pa")
				.setParameter("em", email)
				.setParameter("pa", password)
				.getResultList();
	}	
}
