package com.morningstar.exception;

public class UseralreadyRegistered extends RuntimeException {


	public UseralreadyRegistered() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UseralreadyRegistered(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
